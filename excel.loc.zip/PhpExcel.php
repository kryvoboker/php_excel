<?php

require_once __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class PhpExcel
{
	private ?Spreadsheet $spreadsheet_one = null;
	private string $file_name_one;
	private int $count_something = 0;

	public function __construct(string $spreadsheet_file)
	{
		$this->spreadsheet_one = IOFactory::load($spreadsheet_file);
		$this->file_name_one = basename($spreadsheet_file);
	}

	/**
	 * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
	 */
	private function writeExcel(string $path_to_files, $file_one) : void
	{
		$writer = new Xlsx($this->spreadsheet_one);
		$writer->save($path_to_files . 'new_' . $file_one);
	}

	public function createUpdateSqlForProductPrice_1(array $parameters) : void
	{
		[
			$coordinate_prod_sku,
			$coordinate_prod_price,
			$sql_file,
			$sheet_name,
			$mode_write
		] = $parameters;

		if ($sheet_name) {
			$worksheet = $this->spreadsheet_one->getSheetByName($sheet_name);
		} else {
			$worksheet = $this->spreadsheet_one->getActiveSheet();
		}

		$highest_row = $worksheet->getHighestRow();
		$empty_rows = '';
		$fp = fopen($sql_file, $mode_write);

		for ($row_number = 2; $row_number <= $highest_row; $row_number++) {
			$prod_sku = trim($worksheet->getCell($coordinate_prod_sku . $row_number)->getValue());
			$prod_price = $worksheet->getCell($coordinate_prod_price . $row_number)->getValue();

			if (empty($prod_sku) || !is_numeric($prod_price) || empty($prod_price)) {
				$empty_rows .= "В строкі №$row_number щось відсутнє!!! \n\r";
				continue;
			}

			$sql = "UPDATE gg_product SET `price` = $prod_price WHERE `product_id` = (IFNULL((SELECT `product_id` FROM gg_product WHERE `sku` = '$prod_sku' LIMIT 1), 0));\n";

			fwrite($fp, $sql);
			$this->count_something++;
		}

		fclose($fp);

		echo "Було записано $this->count_something строк\n\r $empty_rows";
	}

	public function createInsertInProductCategory(array $parameters) : void
	{
		[
			$coordinate_prod_sku,
			$coordinate_cat_name_level_1,
			$coordinate_cat_name_level_2,
			$main_parent_cat_id,
			$sql_file,
			$sheet_name,
			$mode_write
		] = $parameters;

		if ($sheet_name) {
			$worksheet = $this->spreadsheet_one->getSheetByName($sheet_name);
		} else {
			$worksheet = $this->spreadsheet_one->getActiveSheet();
		}

		$highest_row = $worksheet->getHighestRow();
		$empty_rows = '';
		$fp = fopen($sql_file, $mode_write);
		$sql = '';

		for ($row_number = 2; $row_number <= $highest_row; $row_number++) {
			$prod_sku = trim($worksheet->getCell($coordinate_prod_sku . $row_number)->getValue());
			$cat_name_level_1 = $worksheet->getCell($coordinate_cat_name_level_1 . $row_number)->getValue();
			$cat_name_level_2 = $worksheet->getCell($coordinate_cat_name_level_2 . $row_number)->getValue();

			if (empty($prod_sku) || (empty($cat_name_level_1) && empty($cat_name_level_2))) {
				$empty_rows .= "В строкі №$row_number щось відсутнє!!! \n\r";
				continue;
			}

			$cat_name_level_1 = str_replace("'", "\'", $cat_name_level_1);

			if (!empty($cat_name_level_2)) {
				$cat_name_level_2 = str_replace("'", "\'", $cat_name_level_2);
				$sql = "INSERT INTO product_to_category (`product_id`, `category_id`) VALUES (IFNULL((SELECT product_id FROM product WHERE sku = '$prod_sku' LIMIT 1), 0), IFNULL((SELECT cd.category_id FROM category_description AS cd RIGHT JOIN category AS c ON (cd.category_id = c.category_id) WHERE cd.`name` = '$cat_name_level_2' AND c.parent_id = (SELECT cd.category_id FROM category AS c RIGHT JOIN category_description AS cd ON (c.category_id = cd.category_id) WHERE cd.`name` = '$cat_name_level_1' AND c.parent_id = $main_parent_cat_id LIMIT 1) LIMIT 1), 0)) ON DUPLICATE KEY UPDATE `category_id` = `category_id`;\n";
			}

			fwrite($fp, $sql);
			$this->count_something++;

			if (!empty($cat_name_level_1)) {
				$sql = "INSERT INTO product_to_category (`product_id`, `category_id`) VALUES (IFNULL((SELECT product_id FROM product WHERE sku = '$prod_sku' LIMIT 1), 0), IFNULL((SELECT c.category_id FROM category_description AS cd RIGHT JOIN category AS c ON (c.category_id = cd.category_id) WHERE c.parent_id = $main_parent_cat_id AND cd.`name` = '$cat_name_level_1' LIMIT 1), 0)) ON DUPLICATE KEY UPDATE `category_id` = `category_id`;\n";
			}

			fwrite($fp, $sql);
			$this->count_something++;
		}

		fclose($fp);

		echo "Було записано $this->count_something строк\n\r $empty_rows";
	}

	public function createInsertSqlInProductSpecials(array $parameters) : void
	{
		[
			$coordinate_prod_sku,
			$coordinate_special_price,
			$customer_group_id,
			$priority,
			$date_end,
			$sql_file,
			$sheet_name,
			$mode_write
		] = $parameters;

		$coordinate_prod_sku = mb_strtolower($coordinate_prod_sku, 'UTF-8');
		$coordinate_special_price = mb_strtolower($coordinate_special_price, 'UTF-8');

		if ($sheet_name) {
			$worksheet = $this->spreadsheet_one->getSheetByName($sheet_name);
		} else {
			$worksheet = $this->spreadsheet_one->getActiveSheet();
		}

		$highest_row = $worksheet->getHighestRow();
		$empty_rows = '';
		$fp = fopen($sql_file, $mode_write);

		for ($row_number = 2; $row_number <= $highest_row; $row_number++) {
			$prod_sku = trim($worksheet->getCell($coordinate_prod_sku . $row_number)->getValue());
			$special_price = (float)trim($worksheet->getCell($coordinate_special_price . $row_number)->getValue());

			if (empty($prod_sku) || empty($special_price) && !is_numeric($special_price)) {
				$empty_rows .= "В строкі №$row_number щось відсутнє!!! \n\r";
				continue;
			}

			$sql = "INSERT INTO `gg_product_special` (`product_id`, `customer_group_id`, `priority`, `price`, `date_end`) VALUES(IFNULL((SELECT `product_id` FROM `gg_product` WHERE `sku` = '$prod_sku' LIMIT 1), 0), $customer_group_id, $priority, $special_price, '$date_end');\r\n";

			fwrite($fp, $sql);
			$this->count_something++;
		}

		fclose($fp);

		echo "Було записано $this->count_something строк\n\r $empty_rows";
	}

	public function createDeleteFromProductSpecials(array $parameters) : void
	{
		[
			$coordinate_prod_sku,
			$customer_group_id,
			$sql_file,
			$sheet_name,
			$mode_write
		] = $parameters;

		$coordinate_prod_sku = mb_strtolower($coordinate_prod_sku, 'UTF-8');

		if ($sheet_name) {
			$worksheet = $this->spreadsheet_one->getSheetByName($sheet_name);
		} else {
			$worksheet = $this->spreadsheet_one->getActiveSheet();
		}

		$highest_row = $worksheet->getHighestRow();
		$empty_rows = '';
		$fp = fopen($sql_file, $mode_write);

		for ($row_number = 2; $row_number <= $highest_row; $row_number++) {
			$prod_sku = trim($worksheet->getCell($coordinate_prod_sku . $row_number)->getValue());

			if (empty($prod_sku)) {
				$empty_rows .= "В строкі №$row_number щось відсутнє!!! \n\r";
				continue;
			}

			$sql = "DELETE FROM product_special WHERE product_id = (IFNULL(SELECT product_id FROM product WHERE sku = '$prod_sku' LIMIT 1), 0) AND customer_group_id = $customer_group_id;\r\n";

			fwrite($fp, $sql);
			$this->count_something++;
		}

		fclose($fp);

		echo "Було записано $this->count_something строк\n\r $empty_rows";
	}

	public function __destruct()
	{
		if ($this->spreadsheet_one instanceof Spreadsheet) {
			$this->spreadsheet_one->disconnectWorksheets();
			unset($this->spreadsheet_one);
		}
	}
}

/*$file = 'C:/Users/User/Documents/Роман/Лайно/Переоцінка ніктойс 11.11.2022.xlsx';

$excel = new PhpExcel($file);

$parameters = [
	'B',
	'D',
	'C:/Users/User/Documents/Роман/Лайно/update_prod-price-for-board-games-from-100_nicktoys.com.ua_11.11.2022.sql',
	'Настільні 100+',
	'w',
];

$excel->createUpdateSqlForProductPrice_1($parameters);*/

/*$file = 'C:/Users/User/Documents/Роман/добавление чего-то/подкатегории для алмазки avstore.com.ua_15.11.2022/Алмазка жанри(АвтоматическиВосстановлено)_1.xls';

$excel = new PhpExcel($file);

$parameters = [
	'C',
	'D',
	'E',
	60,
	'C:/Users/User/Documents/Роман/добавление чего-то/подкатегории для алмазки avstore.com.ua_15.11.2022/create-insert-into-product-to-category-avstore.com.ua_18.11.2022.sql',
	null,
	'w',
];

$excel->createInsertInProductCategory($parameters);*/

/*$file = 'C:/Users/User/Documents/Роман/добавление акционных цен/23.11.2022_nicktoys.com.ua/Ігри - ніктойс.xlsx';

$excel = new PhpExcel($file);

$parameters = [
	'a',
	'e',
	1,
	1,
	'2022-11-30',
	'C:/Users/User/Documents/Роман/добавление акционных цен/23.11.2022_nicktoys.com.ua/insert-product-special-nicktoys.com.ua-23.11.2022.sql',
	'Лист1',
	'w',
];

$excel->createInsertSqlInProductSpecials($parameters);*/

$file = 'C:/Users/User/Documents/Роман/Лайно/Ігри та набори - стратег.xlsx';

$excel = new PhpExcel($file);

$parameters = [
	'a',
	1,
	'C:/Users/User/Documents/Роман/Лайно/create-delete-sql-from-product-special-strateg.ua-23.11.2022.sql',
	'Лист1',
	'w',
];

$excel->createDeleteFromProductSpecials($parameters);